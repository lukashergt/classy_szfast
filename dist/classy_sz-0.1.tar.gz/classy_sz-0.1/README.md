Python module for the acceleration of class_sz and interface with likelihood codes. 
