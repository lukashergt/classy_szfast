path_to_cosmopower_organization = '/Users/boris/Work/CLASS-SZ/SO-SZ/class_sz/cosmopower-organization'
